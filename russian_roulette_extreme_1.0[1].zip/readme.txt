Ceci est un programme de roulette russe si vous echouez votre PC crashera nous ne sommes pas résponsable si le programme peut nuire a la santé de votre PC.
Le déroulement du jeu:
    Choissisez un  nombre ou chiffre de 1 a 100 si le nombre généré est égal à celui que vous avez choisie vous perdez.